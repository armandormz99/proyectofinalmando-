﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CajeroAutomatico
{
    class Datos
    {
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Pin { get; set; }
        public decimal Monto { get; set; }

    }
}
