﻿namespace CajeroAutomatico.eng
{
    partial class RetiroEfectivo_eng
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RetiroEfectivo_eng));
            this.buttonOtro = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button300 = new System.Windows.Forms.Button();
            this.button500 = new System.Windows.Forms.Button();
            this.button1000 = new System.Windows.Forms.Button();
            this.button2000 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonOtro
            // 
            this.buttonOtro.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOtro.Location = new System.Drawing.Point(421, 287);
            this.buttonOtro.Name = "buttonOtro";
            this.buttonOtro.Size = new System.Drawing.Size(111, 40);
            this.buttonOtro.TabIndex = 12;
            this.buttonOtro.Text = "Other";
            this.buttonOtro.UseVisualStyleBackColor = true;
            this.buttonOtro.Click += new System.EventHandler(this.buttonOtro_Click);
            // 
            // button100
            // 
            this.button100.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button100.Location = new System.Drawing.Point(421, 238);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(111, 40);
            this.button100.TabIndex = 11;
            this.button100.Text = "RD$ 100";
            this.button100.UseVisualStyleBackColor = true;
            this.button100.Click += new System.EventHandler(this.button100_Click);
            // 
            // button300
            // 
            this.button300.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button300.Location = new System.Drawing.Point(421, 191);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(111, 40);
            this.button300.TabIndex = 10;
            this.button300.Text = "RD$ 300";
            this.button300.UseVisualStyleBackColor = true;
            this.button300.Click += new System.EventHandler(this.button300_Click);
            // 
            // button500
            // 
            this.button500.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button500.Location = new System.Drawing.Point(12, 285);
            this.button500.Name = "button500";
            this.button500.Size = new System.Drawing.Size(111, 40);
            this.button500.TabIndex = 9;
            this.button500.Text = "RD$ 500";
            this.button500.UseVisualStyleBackColor = true;
            this.button500.Click += new System.EventHandler(this.button500_Click);
            // 
            // button1000
            // 
            this.button1000.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1000.Location = new System.Drawing.Point(12, 236);
            this.button1000.Name = "button1000";
            this.button1000.Size = new System.Drawing.Size(111, 40);
            this.button1000.TabIndex = 8;
            this.button1000.Text = "RD$ 1,000";
            this.button1000.UseVisualStyleBackColor = true;
            this.button1000.Click += new System.EventHandler(this.button1000_Click);
            // 
            // button2000
            // 
            this.button2000.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2000.Location = new System.Drawing.Point(12, 189);
            this.button2000.Name = "button2000";
            this.button2000.Size = new System.Drawing.Size(111, 40);
            this.button2000.TabIndex = 7;
            this.button2000.Text = "RD$ 2,000";
            this.button2000.UseVisualStyleBackColor = true;
            this.button2000.Click += new System.EventHandler(this.button2000_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 349);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(111, 40);
            this.button1.TabIndex = 13;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // RetiroEfectivo_eng
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(544, 401);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonOtro);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button300);
            this.Controls.Add(this.button500);
            this.Controls.Add(this.button1000);
            this.Controls.Add(this.button2000);
            this.Name = "RetiroEfectivo_eng";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RetiroEfectivo_eng";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonOtro;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button300;
        private System.Windows.Forms.Button button500;
        private System.Windows.Forms.Button button1000;
        private System.Windows.Forms.Button button2000;
        private System.Windows.Forms.Button button1;
    }
}